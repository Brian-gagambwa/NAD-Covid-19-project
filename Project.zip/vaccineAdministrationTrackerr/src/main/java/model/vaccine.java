package model;

public class vaccine {
    
    
    private String name ; 
    private String date ; 
    private String role ; 
    private String status;  
    
    
    
    
    public String getname() {
		return name;
	}
	public void setname(String name) {
		this.name = name;
	}
	
	

	 public String getdate() {
			return date;
		}
		public void setdate(String date) {
			this.date = date;
		}
		
		
		
   	 public String getrole() {
		return role;
		}
   	public void setrole(String role) {
		this.role = role;
		}
   	
   	
			
		 public String getstatus() {
			return status;
		}
		public void setstatus(String status) {
			this.status = status;
	  }
}

