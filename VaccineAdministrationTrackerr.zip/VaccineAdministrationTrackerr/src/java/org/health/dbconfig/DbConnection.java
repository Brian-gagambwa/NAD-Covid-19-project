/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.health.dbconfig;

import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class DbConnection {
    private String password = "Lancer@2612";
    private String user = "root";
    private String jdbcdriver = "com.mysql.jdbc.Driver";
    private String jdbcUrl = "jdbc:mysql://localhost:3306/covid19tracker";
    
    //connection
    public Connection getConnection() throws ClassNotFoundException{
        Connection connection = null;
        
        try{
            Class.forName(this.jdbcdriver);
            try{
                connection = DriverManager.getConnection(this.jdbcUrl,this.user,this.password);
            }
            catch(SQLException e){
            System.out.println("Failed to connect "+e.getMessage());
            out.println("We connected");
        }
        }catch(ClassNotFoundException ex){
            System.out.println("Failed to connect "+ex.getMessage());
        }
        return connection;
        
    }
    
    public void closeConnection() throws ClassNotFoundException, SQLException{
        this.getConnection().close();
    }
}
