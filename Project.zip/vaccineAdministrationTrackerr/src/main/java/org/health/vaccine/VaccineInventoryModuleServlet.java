package org.health.vaccine;

import java.io.IOException;
import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import databaseconnection.DatabaseConnection;
import model.vaccine;

/**
 * Servlet implementation class VaccineInventoryModuleServlet
 */
@WebServlet("/VaccineInventoryModuleServlet")
public class VaccineInventoryModuleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VaccineInventoryModuleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String connectionURL = "jdbc:mysql://localhost:3306/covid19tracker?useSSL=false";
		Connection connection = null;
		
		ResultSet rs;
		response.setContentType("text/html");
		
	//	List datalist new ArrayList();
		
		List<Array> datalist = new ArrayList<Array>();
		
		try {
			//Load the database driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Get a Connection to the database
			
			connection = DriverManager.getConnection(connectionURL, "root","Lancer@2612");
			
			//Select the data from the database
			
			String sql = "select * from vaccine";
			
			Statement s = connection.createStatement();
			
			s.executeQuery(sql);
			
			rs = s.getResultSet();
			
			while (rs.next()) {
				
				//Add records in the data list 
				
				datalist.add(rs.getArray("id"));
				
				datalist.add(rs.getArray("name"));
				
				datalist.add(rs.getArray("date"));
				
				datalist.add(rs.getArray("role"));
				
				datalist.add(rs.getArray("status"));
				
			}
			
			rs.close();
			
			s.close();
			
		}catch(Exception e) {
			
			System.out.print("Exception is ;"+e);
			
		}
		
		request.setAttribute("data",datalist);
		
		//Dispatching request
		
		
		
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("vaccine.jsp");
		
		if (dispatcher != null) {
		dispatcher.forward(request, response);
	}
		
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
	/*	response.setContentType("text/html");  
        PrintWriter pw = response.getWriter(); 
        //String connectionURL = "jdbc:mysql://127.0.0.1:3306/newData";// newData is the database  
        //Connection connection;  
        Connection conn=null;
        String url="jdbc:mysql://127.0.0.1:3306";
        String dbName="covid19tracker";
      //  String driver="com.mysql.jdbc.Driver";
        String driver="com.mysql.cj.jdbc.Driver";
        
     //   SELECT * FROM Covid_19_tracker.Vaccine_table;
    //String dbUserName="root";
    //String dbPassword="root";

    try{  
    	
      String name = request.getParameter("name");  
      String date = request.getParameter("date");  
      String role = request.getParameter("role");  
      String status = request.getParameter("status");   

      Class.forName(driver);  
      conn = DriverManager.getConnection(url+dbName,"root", "Lancer@2612");
      PreparedStatement pst =(PreparedStatement) 
    		  conn.prepareStatement("insert into vaccine(name,date,role,status) values(?,?,?,?)");//try2 is the name of the table  

      pst.setString(1,name);  
      pst.setString(2,date);        
      pst.setString(3,role);
      pst.setString(4,status);


      int i = pst.executeUpdate();
      conn.commit(); 
      String msg=" ";
      if(i!=0){  
        msg="Record has been inserted";
        pw.println("<font size='6' color=blue>" + msg + "</font>");  


      }  
      else{  
        msg="failed to insert the data";
        pw.println("<font size='6' color=blue>" + msg + "</font>");
       }  
      pst.close();
    }  
    catch (Exception e){  
      pw.println(e);  
    }  
        */
		
		
		String name = request.getParameter("name");
        String date = request.getParameter("date");
        String role = request.getParameter("role");
        String status = request.getParameter("status");

        vaccine vaccine = new vaccine();
        vaccine.setname(name);
        vaccine.setdate(date);
        vaccine.setrole(role);
        vaccine.setstatus(role);

        try {
            DatabaseConnection.addvaccine(vaccine);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        
        
		 RequestDispatcher dispatcher = request.getRequestDispatcher("vaccine.jsp");
			dispatcher.forward(request, response);
	}

}
