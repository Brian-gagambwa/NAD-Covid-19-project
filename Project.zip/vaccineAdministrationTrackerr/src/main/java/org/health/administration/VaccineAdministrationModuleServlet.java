package org.health.administration;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import databaseconnection.bookingDatabaseconnection;
import databaseconnection.patientlistDatabase;
import model.booking;
import model.patient;

/**
 * Servlet implementation class VaccineAdministrationModuleServlet
 */
@WebServlet("/VaccineAdministrationModuleServlet")
public class VaccineAdministrationModuleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VaccineAdministrationModuleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher dispatcher = request.getRequestDispatcher("VaccineAdmin.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		String name = request.getParameter("name");
        String nin = request.getParameter("nin");
        String healthcentre = request.getParameter("number");
        String batchnumber = request.getParameter("email");
        String date = request.getParameter("date");
        String vaccine = request.getParameter("vaccine");
       

       // vaccine vaccine = new vaccine();
        patient p = new patient();
        p.setName(name);
        p.setNin(nin);
        p.setHealthcentre(healthcentre);
        p.setBatchnumber(batchnumber);
        p.setDate(date);
        p.setVaccine(vaccine);

        try {
            patientlistDatabase.addpatient(p);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
		RequestDispatcher dispatcher = request.getRequestDispatcher("VaccineAdmin.jsp");
		dispatcher.forward(request, response);
	}

}
