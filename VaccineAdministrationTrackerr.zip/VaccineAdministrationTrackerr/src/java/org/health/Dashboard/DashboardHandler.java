/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/TagHandler.java to edit this template
 */
package org.health.Dashboard;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.JspFragment;
import javax.servlet.jsp.tagext.SimpleTagSupport;
import org.health.dbconfig.DbConnection;

/**
 *
 * @author ssebugandadenis
 */
public class DashboardHandler extends SimpleTagSupport {
    
    DbConnection conn = new DbConnection();
    
    Connection newConn;

   

    public DashboardHandler() throws ClassNotFoundException {
        this.newConn = conn.getConnection();
    }

    

    /**
     * Called by the container to invoke this tag. The implementation of this
     * method is provided by the tag library developer, and handles all tag
     * processing, body iteration, etc.
     */
    @Override
    public void doTag() throws JspException {
        JspWriter out = getJspContext().getOut();
        
        try {
            // TODO: insert code to write html before writing the body content.
            // e.g.:
            //
            // out.println("<strong>" + attribute_1 + "</strong>");
            // out.println("    <blockquote>");
            
            
             Statement st = newConn.createStatement();
            
            ResultSet rs = st.executeQuery("SELECT COUNT(id) FROM healthcentre");
            
            String count = "";
            
           while(rs.next()){
               count = rs.getString(1);
           
           }
           
           out.println("<h2>"+count+"</h2>");

/////////////////////////////////////////
//Statement st2 = newConn.createStatement();
//ResultSet rs2 = st.executeQuery("SELECT COUNT(name) FROM patient");
//            
//             String count1 = "";
//            
//           while(rs.next()){
//               count1 = rs2.getString(1);
//           
//           }
//          
//           out.println("<h2>"+count1+"</h2>");
           
            JspFragment f = getJspBody();
            if (f != null) {
                f.invoke(out);
            }

            // TODO: insert code to write html after writing the body content.
            // e.g.:
            //
            // out.println("    </blockquote>");
        } catch (java.io.IOException ex) {
            throw new JspException("Error in DashboardHandler tag", ex);
        } catch (SQLException ex) {
            Logger.getLogger(DashboardHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
