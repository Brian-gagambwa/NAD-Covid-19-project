package org.health.booking;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import databaseconnection.DatabaseConnection;
import databaseconnection.bookingDatabaseconnection;
import model.booking;
import model.vaccine;

/**
 * Servlet implementation class VAccinationbokkingAndAdvisoryModuleServlet
 */
@WebServlet("/VAccinationbokkingAndAdvisoryModuleServlet")
public class VAccinationbookingAndAdvisoryModuleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VAccinationbookingAndAdvisoryModuleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher dispatcher = request.getRequestDispatcher("booking.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
		
		String name = request.getParameter("name");
        String nin = request.getParameter("nin");
        String number = request.getParameter("number");
        String email = request.getParameter("email");
        String date = request.getParameter("date");
        String hospital = request.getParameter("hospital");
        String vaccine = request.getParameter("vaccine");
        String location = request.getParameter("location");
        String city = request.getParameter("city");

       // vaccine vaccine = new vaccine();
        booking booking = new booking();
        booking.setName(name);
        booking.setNin(nin);
        booking.setNumber(number);
        booking.setEmail(email);
        booking.setDate(date);
        booking.setHospital(hospital);
        booking.setVaccine(vaccine);
        booking.setLoaction(location);
        booking.setCity(city);

        try {
            bookingDatabaseconnection.addbooking(booking);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        
        
        
		RequestDispatcher dispatcher = request.getRequestDispatcher("booking.jsp");
		dispatcher.forward(request, response);
	}

}
