/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/TagHandler.java to edit this template
 */
package org.health.booking;

import java.sql.Connection;
import java.sql.SQLException;
import org.health.dbconfig.DbConnection;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.JspFragment;
import javax.servlet.jsp.tagext.SimpleTagSupport;

/**
 *
 * @author ssebugandadenis
 */
public class Vaccinationbooking extends SimpleTagSupport {
    DbConnection conn = new DbConnection();
    
    Connection newConn;

    private String table;
    private String values;

    public Vaccinationbooking() throws ClassNotFoundException {
        this.newConn = conn.getConnection();
    }

    /**
     * Called by the container to invoke this tag. The implementation of this
     * method is provided by the tag library developer, and handles all tag
     * processing, body iteration, etc.
     */
    @Override
    public void doTag() throws JspException {
        JspWriter out = getJspContext().getOut();
        
        try {
            // TODO: insert code to write html before writing the body content.
            // e.g.:
            //
            // out.println("<strong>" + attribute_1 + "</strong>");
            // out.println("    <blockquote>");
            String[] newValues = values.split(", ");
            out.println("The values are "+newValues[0]);
            Statement st = newConn.createStatement();
            
            if(newValues.length > 1){
                st.execute("INSERT INTO booking\" +\n" +
"            \"  (id,name,nin,number,email,date,healthcentre,vaccine,location,city) VALUES(NULL, '"+newValues[0]+"','"+newValues[1]+"','"+newValues[2]+"','"+newValues[3]+"','"+newValues[4]+"','"+newValues[5]+"','"+newValues[6]+"','"+newValues[7]+"','"+newValues[8]+"','"+newValues[9]+"',)");
            }
            
            JspFragment f = getJspBody();
            if (f != null) {
                f.invoke(out);
            }

            // TODO: insert code to write html after writing the body content.
            // e.g.:
            //
            // out.println("    </blockquote>");
        } catch (java.io.IOException ex) {
            throw new JspException("Error in Vaccinationbooking tag", ex);
        } catch (SQLException ex) {
            Logger.getLogger(Vaccinationbooking.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void setTable(String table) {
        this.table = table;
    }

    public void setValues(String values) {
        this.values = values;
    }
    
}
