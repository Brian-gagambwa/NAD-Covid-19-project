package model;

public class healthcentre {
	
	
	 private String healthcentre ; 
	 private String location ; 
	 private String vaccinesadministered ; 
	 private String vaccinesdispatched;
	 
	 
	public String getHealthcentre() {
		return healthcentre;
	}
	public void setHealthcentre(String healthcentre) {
		this.healthcentre = healthcentre;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getVaccinesadministered() {
		return vaccinesadministered;
	}
	public void setVaccinesadministered(String vaccinesadministered) {
		this.vaccinesadministered = vaccinesadministered;
	}
	public String getVaccinesdispatched() {
		return vaccinesdispatched;
	}
	public void setVaccinesdispatched(String vaccinesdispatched) {
		this.vaccinesdispatched = vaccinesdispatched;
	}
	

}
