package model;

public class patient {
	
	 private String name ; 
	 private String nin ; 
	 private String healthcentre ; 
	 private String batchnumber;
	 private String date ;  
	 private String vaccine;
	 
	 
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNin() {
		return nin;
	}
	public void setNin(String nin) {
		this.nin = nin;
	}
	public String getHealthcentre() {
		return healthcentre;
	}
	public void setHealthcentre(String healthcentre) {
		this.healthcentre = healthcentre;
	}
	public String getBatchnumber() {
		return batchnumber;
	}
	public void setBatchnumber(String batchnumber) {
		this.batchnumber = batchnumber;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getVaccine() {
		return vaccine;
	}
	public void setVaccine(String vaccine) {
		this.vaccine = vaccine;
	}
	 

}
