/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/TagHandler.java to edit this template
 */
package org.health.administration;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.JspFragment;
import javax.servlet.jsp.tagext.SimpleTagSupport;
import org.health.dbconfig.DbConnection;

/**
 *
 * @author ssebugandadenis
 */
public class VaccineAdminHandler extends SimpleTagSupport {

    DbConnection conn = new DbConnection();
    
    Connection newConn;

    private String table;
    private String values;

    public  VaccineAdminHandler() throws ClassNotFoundException {
        this.newConn = conn.getConnection();
    }

    /**
     * Called by the container to invoke this tag. The implementation of this
     * method is provided by the tag library developer, and handles all tag
     * processing, body iteration, etc.
     */
    @Override
    public void doTag() throws JspException {
        JspWriter out = getJspContext().getOut();
        
        try {
            // TODO: insert code to write html before writing the body content.
            // e.g.:
            //
            // out.println("<strong>" + attribute_1 + "</strong>");
            // out.println("    <blockquote>");

            
            
            Statement st = newConn.createStatement();
            
            ResultSet rs = st.executeQuery("SELECT * FROM patient");
            int id = 1;
           while(rs.next()){
               out.println(""+
                 "<tr scope=\"row\">"+
                 "<td>"+(id++)+"</td>"+
                 "<td>"+rs.getString("name")+"</td>"+
                 "<td>"+rs.getString("nin")+"</td>"+
                 "<td>"+rs.getString("healthcentre")+"</td>"+
                 "<td>"+rs.getString("batch number")+"</td>"+
                 "<td>"+rs.getString("date")+"</td>"+
                 "<td>"+rs.getString("vaccine")+"</td>"+
                 "</tr>"
               );
           }
            JspFragment f = getJspBody();
            if (f != null) {
                f.invoke(out);
            }

            // TODO: insert code to write html after writing the body content.
            // e.g.:
            //
            // out.println("    </blockquote>");
        } catch (java.io.IOException ex) {
            throw new JspException("Error in VaccineAdminHandler tag", ex);
        } catch (SQLException ex) {
            Logger.getLogger(VaccineAdminHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void setTable(String table) {
        this.table = table;
    }

    public void setValues(String values) {
        this.values = values;
    }
    
}
